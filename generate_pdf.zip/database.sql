-- Base de données pour Gestion des Dépôts
-- À exécuter dans phpMyAdmin ou MySQL

CREATE DATABASE IF NOT EXISTS `depot_manager` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `depot_manager`;

-- ====================================
-- Table des clients
-- ====================================
CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prenom` varchar(100) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `date_creation` timestamp DEFAULT CURRENT_TIMESTAMP,
  `date_modification` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_nom_prenom` (`nom`, `prenom`),
  INDEX `idx_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================
-- Table des statuts
-- ====================================
CREATE TABLE `statuts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `couleur_hex` varchar(7) NOT NULL DEFAULT '#3498db',
  `action` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `ordre` int(11) NOT NULL DEFAULT 1,
  `date_creation` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nom` (`nom`),
  INDEX `idx_ordre` (`ordre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================
-- Table des dépôts
-- ====================================
CREATE TABLE `depots` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_depot` varchar(50) DEFAULT NULL,
  `client_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `designation_references` text DEFAULT NULL,
  `observation_travaux` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `date_depot` date DEFAULT NULL,
  `date_prevue` date DEFAULT NULL,
  `mot_de_passe` varchar(255) DEFAULT NULL,
  `donnees_sauvegarder` enum('Oui','Non') DEFAULT 'Non',
  `outlook_sauvegarder` enum('Oui','Non') DEFAULT 'Non',
  `informations_complementaires` text DEFAULT NULL,
  `archived` tinyint(1) DEFAULT 0,
  `date_creation` timestamp DEFAULT CURRENT_TIMESTAMP,
  `date_modification` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_depot` (`numero_depot`),
  KEY `fk_depot_client` (`client_id`),
  KEY `fk_depot_status` (`status_id`),
  INDEX `idx_date_depot` (`date_depot`),
  INDEX `idx_archived` (`archived`),
  CONSTRAINT `fk_depot_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_depot_status` FOREIGN KEY (`status_id`) REFERENCES `statuts` (`status_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================
-- Table des archives
-- ====================================
CREATE TABLE `archives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `depot_id` int(11) NOT NULL,
  `numero_depot` varchar(50) DEFAULT NULL,
  `client_nom` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `notes` text DEFAULT NULL,
  `date_depot` date DEFAULT NULL,
  `date_archive` date DEFAULT NULL,
  `statut_final` varchar(100) DEFAULT NULL,
  `raison_archivage` varchar(255) DEFAULT 'Archivage automatique',
  `date_creation` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_depot_id` (`depot_id`),
  INDEX `idx_date_archive` (`date_archive`),
  INDEX `idx_client_nom` (`client_nom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================
-- Table des paramètres système
-- ====================================
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cle` varchar(100) NOT NULL,
  `valeur` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `date_modification` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cle` (`cle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================
-- Table pour les numéros de dépôt
-- ====================================
CREATE TABLE `depot_counter` (
  `year` int(4) NOT NULL,
  `counter` int(11) NOT NULL DEFAULT 1,
  `last_number` varchar(50) DEFAULT NULL,
  `date_modification` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================
-- DONNÉES PAR DÉFAUT
-- ====================================

-- Insertion des statuts par défaut
INSERT INTO `statuts` (`id`, `nom`, `couleur_hex`, `action`, `description`, `ordre`) VALUES
(1, 'En attente', '#e74c3c', 'Traitement initial', 'Dépôt reçu, en attente de traitement', 1),
(2, 'En cours', '#f39c12', 'Traitement en cours', 'Réparation ou service en cours', 2),
(3, 'Prêt', '#3498db', 'Contacter le client', 'Travail terminé, prêt à récupérer', 3),
(4, 'Terminé', '#27ae60', 'Dépôt récupéré', 'Dépôt récupéré par le client', 4);

-- Insertion des clients par défaut
INSERT INTO `clients` (`id`, `prenom`, `nom`, `email`, `telephone`, `adresse`, `notes`) VALUES
(1, 'Martin', 'Dupont', 'martin.dupont@email.com', '06 12 34 56 78', '123 Rue de la Paix, 75001 Paris', 'Client régulier'),
(2, 'Sophie', 'Bernard', 'sophie.bernard@email.com', '06 87 65 43 21', '456 Avenue des Champs, 69000 Lyon', ''),
(3, 'Pierre', 'Martin', 'pierre.martin@email.com', '06 11 22 33 44', '789 Boulevard Saint-Michel, 13000 Marseille', 'Professionnel'),
(4, 'Julie', 'Moreau', 'julie.moreau@email.com', '06 55 44 33 22', '321 Rue du Commerce, 33000 Bordeaux', ''),
(5, 'Thomas', 'Lefebvre', 'thomas.lefebvre@email.com', '06 99 88 77 66', '654 Impasse des Lilas, 59000 Lille', 'Client VIP');

-- Insertion des paramètres par défaut
INSERT INTO `settings` (`cle`, `valeur`, `description`) VALUES
('entreprise_nom', 'WEB INFORMATIQUE', 'Nom de l\'entreprise'),
('entreprise_adresse', '154 bis rue du général de Gaulle\n76770 LE HOULME', 'Adresse de l\'entreprise'),
('entreprise_tel1', '06.99.50.76.76', 'Téléphone principal'),
('entreprise_tel2', '02.35.74.19.29', 'Téléphone secondaire'),
('entreprise_email', 'contact@webinformatique.eu', 'Email de contact'),
('entreprise_siret', '493 928 139 00010', 'Numéro SIRET'),
('entreprise_tva', 'FR493928139', 'Numéro TVA'),
('entreprise_capital', '8.000€', 'Capital social'),
('depot_delai_propriete', '90', 'Délai en jours avant propriété du matériel'),
('max_depots_display', '25', 'Nombre maximum de dépôts affichés'),
('auto_archive_days', '30', 'Nombre de jours avant archivage automatique'),
('auto_backup', '1', 'Sauvegarde automatique activée'),
('backup_frequency', '3600', 'Fréquence de sauvegarde en secondes');

-- Insertion de l'année courante pour le compteur
INSERT INTO `depot_counter` (`year`, `counter`) VALUES (YEAR(NOW()), 1);

-- Insertion de quelques dépôts de démonstration
INSERT INTO `depots` (`numero_depot`, `client_id`, `status_id`, `description`, `designation_references`, `observation_travaux`, `notes`, `date_depot`, `date_prevue`, `donnees_sauvegarder`, `outlook_sauvegarder`) VALUES
('2025/001/001', 1, 2, 'Réparation écran iPhone 12', 'iPhone 12 - Écran cassé', 'Remplacement écran + protection verre trempé', 'Client pressé, livraison express', '2025-06-24', '2025-06-26', 'Non', 'Non'),
('2025/001/002', 2, 3, 'Changement batterie Samsung Galaxy S21', 'Samsung Galaxy S21 - Batterie HS', 'Remplacement batterie d\'origine', 'Téléphone sous garantie expirée', '2025-06-23', '2025-06-25', 'Oui', 'Non'),
('2025/001/003', 3, 1, 'Réparation carte mère PC portable', 'ASUS VivoBook - Ne démarre plus', 'Diagnostic carte mère + réparation', 'Possible problème d\'alimentation', '2025-06-25', '2025-06-30', 'Oui', 'Oui'),
('2025/001/004', 4, 4, 'Installation Windows 11 + logiciels', 'PC Dell Inspiron', 'Installation propre + suite Office', 'Migration depuis Windows 10', '2025-06-22', '2025-06-24', 'Oui', 'Oui');

-- ====================================
-- VUES UTILES
-- ====================================

-- Vue pour les dépôts avec informations client et statut
CREATE VIEW `view_depots_complets` AS
SELECT 
    d.id,
    d.numero_depot,
    d.description,
    d.designation_references,
    d.observation_travaux,
    d.notes,
    d.date_depot,
    d.date_prevue,
    d.mot_de_passe,
    d.donnees_sauvegarder,
    d.outlook_sauvegarder,
    d.informations_complementaires,
    d.date_creation,
    d.date_modification,
    CONCAT(c.prenom, ' ', c.nom) AS client_nom,
    c.prenom AS client_prenom,
    c.nom AS client_nom_famille,
    c.email AS client_email,
    c.telephone AS client_telephone,
    c.adresse AS client_adresse,
    s.nom AS statut_nom,
    s.couleur_hex AS statut_couleur,
    s.action AS statut_action,
    s.ordre AS statut_ordre
FROM depots d
LEFT JOIN clients c ON d.client_id = c.id
LEFT JOIN statuts s ON d.status_id = s.id
WHERE d.archived = 0
ORDER BY d.date_creation DESC;

-- Vue pour les statistiques
CREATE VIEW `view_statistiques` AS
SELECT 
    (SELECT COUNT(*) FROM depots WHERE archived = 0) AS total_depots,
    (SELECT COUNT(*) FROM clients) AS total_clients,
    (SELECT COUNT(*) FROM depots WHERE status_id = (SELECT id FROM statuts WHERE nom = 'Terminé') AND archived = 0) AS depots_termines,
    (SELECT COUNT(*) FROM depots WHERE status_id != (SELECT id FROM statuts WHERE nom = 'Terminé') AND archived = 0) AS depots_en_attente,
    (SELECT COUNT(*) FROM archives) AS total_archives;

-- ====================================
-- FONCTIONS ET PROCÉDURES
-- ====================================

-- Fonction pour générer le prochain numéro de dépôt
DELIMITER $$
CREATE FUNCTION `generate_depot_number`() RETURNS VARCHAR(50) CHARSET utf8mb4
READS SQL DATA
DETERMINISTIC
BEGIN
    DECLARE next_number VARCHAR(50);
    DECLARE current_year INT;
    DECLARE current_counter INT;
    
    SET current_year = YEAR(NOW());
    
    -- Vérifier si l'année existe dans la table
    SELECT counter INTO current_counter 
    FROM depot_counter 
    WHERE year = current_year;
    
    -- Si l'année n'existe pas, l'insérer
    IF current_counter IS NULL THEN
        INSERT INTO depot_counter (year, counter) VALUES (current_year, 1);
        SET current_counter = 1;
    END IF;
    
    -- Générer le numéro au format YYYY/XXX/NNN
    SET next_number = CONCAT(
        current_year, 
        '/001/',
        LPAD(current_counter, 3, '0')
    );
    
    -- Incrémenter le compteur
    UPDATE depot_counter 
    SET counter = counter + 1, last_number = next_number 
    WHERE year = current_year;
    
    RETURN next_number;
END$$
DELIMITER ;

-- Procédure pour archiver automatiquement les anciens dépôts
DELIMITER $$
CREATE PROCEDURE `archive_old_depots`(IN days_old INT)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE depot_id INT;
    DECLARE depot_cursor CURSOR FOR 
        SELECT d.id 
        FROM depots d 
        INNER JOIN statuts s ON d.status_id = s.id 
        WHERE s.nom = 'Terminé' 
        AND d.date_modification < DATE_SUB(NOW(), INTERVAL days_old DAY)
        AND d.archived = 0;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN depot_cursor;
    
    archive_loop: LOOP
        FETCH depot_cursor INTO depot_id;
        IF done THEN
            LEAVE archive_loop;
        END IF;
        
        -- Archiver le dépôt
        CALL `archive_depot`(depot_id);
    END LOOP;
    
    CLOSE depot_cursor;
END$$
DELIMITER ;

-- Procédure pour archiver un dépôt spécifique
DELIMITER $$
CREATE PROCEDURE `archive_depot`(IN depot_id INT)
BEGIN
    DECLARE client_nom_complet VARCHAR(255);
    DECLARE depot_numero VARCHAR(50);
    DECLARE depot_desc TEXT;
    DECLARE depot_notes TEXT;
    DECLARE depot_date DATE;
    DECLARE statut_final VARCHAR(100);
    
    -- Récupérer les informations du dépôt
    SELECT 
        d.numero_depot,
        d.description,
        d.notes,
        d.date_depot,
        CONCAT(c.prenom, ' ', c.nom),
        s.nom
    INTO 
        depot_numero,
        depot_desc,
        depot_notes,
        depot_date,
        client_nom_complet,
        statut_final
    FROM depots d
    LEFT JOIN clients c ON d.client_id = c.id
    LEFT JOIN statuts s ON d.status_id = s.id
    WHERE d.id = depot_id;
    
    -- Insérer dans les archives
    INSERT INTO archives (
        depot_id,
        numero_depot,
        client_nom,
        description,
        notes,
        date_depot,
        date_archive,
        statut_final
    ) VALUES (
        depot_id,
        depot_numero,
        client_nom_complet,
        depot_desc,
        depot_notes,
        depot_date,
        CURDATE(),
        statut_final
    );
    
    -- Marquer le dépôt comme archivé
    UPDATE depots SET archived = 1 WHERE id = depot_id;
END$$
DELIMITER ;

-- ====================================
-- INDEX SUPPLÉMENTAIRES POUR PERFORMANCE
-- ====================================

-- Index pour les recherches fréquentes
CREATE INDEX idx_depots_search ON depots(description(100), designation_references(100));
CREATE INDEX idx_clients_search ON clients(prenom, nom, email);
CREATE INDEX idx_depots_dates ON depots(date_depot, date_prevue);
CREATE INDEX idx_depots_status_date ON depots(status_id, date_creation);

-- ====================================
-- ÉVÉNEMENTS PROGRAMMÉS (optionnel)
-- ====================================

-- Événement pour archiver automatiquement les anciens dépôts (lance tous les jours à 2h du matin)
CREATE EVENT IF NOT EXISTS `auto_archive_depots`
ON SCHEDULE EVERY 1 DAY STARTS '2025-01-01 02:00:00'
DO CALL archive_old_depots(30);

-- Activer le scheduler d'événements
SET GLOBAL event_scheduler = ON;

-- ====================================
-- PERMISSIONS (à adapter selon vos besoins)
-- ====================================

-- Créer un utilisateur dédié (optionnel)
-- CREATE USER 'depot_user'@'localhost' IDENTIFIED BY 'secure_password';
-- GRANT SELECT, INSERT, UPDATE, DELETE ON depot_manager.* TO 'depot_user'@'localhost';
-- FLUSH PRIVILEGES;