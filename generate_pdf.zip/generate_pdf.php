<?php
/**
 * Générateur de PDF pour les fiches de dépôt
 * Template identique au document fourni
 */

require_once 'config.php';

// Télécharger TCPDF si pas installé : https://tcpdf.org/
// Ou via Composer : composer require tecnickcom/tcpdf
require_once 'tcpdf/tcpdf.php';

/**
 * Génère un PDF de fiche de dépôt
 */
function generateDepotPDF($depotId) {
    try {
        $db = Database::getInstance();
        
        // Récupérer les données du dépôt
        $depot = $db->fetchOne(
            "SELECT d.*, 
                    CONCAT(c.prenom, ' ', c.nom) as client_nom,
                    c.prenom, c.nom, c.email, c.telephone, c.adresse,
                    s.nom as statut_nom, s.couleur_hex
             FROM depots d 
             LEFT JOIN clients c ON d.client_id = c.id 
             LEFT JOIN statuts s ON d.status_id = s.id 
             WHERE d.id = ?",
            [$depotId]
        );
        
        if (!$depot) {
            throw new Exception('Dépôt non trouvé');
        }
        
        // Récupérer les paramètres de l'entreprise
        $settings = $db->fetchAll("SELECT cle, valeur FROM settings WHERE cle LIKE 'entreprise_%'");
        $company = [];
        foreach ($settings as $setting) {
            $company[str_replace('entreprise_', '', $setting['cle'])] = $setting['valeur'];
        }
        
        // Créer le PDF
        $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
        
        // Informations du document
        $pdf->SetCreator(PDF_CREATOR);
        $pdf->SetAuthor(PDF_AUTHOR);
        $pdf->SetTitle('Fiche de dépôt #' . $depot['numero_depot']);
        $pdf->SetSubject(PDF_SUBJECT);
        $pdf->SetKeywords(PDF_KEYWORDS);
        
        // Supprimer header et footer par défaut
        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);
        
        // Marges
        $pdf->SetMargins(15, 15, 15);
        $pdf->SetAutoPageBreak(TRUE, 15);
        
        // Ajouter une page
        $pdf->AddPage();
        
        // Générer le contenu
        generatePDFContent($pdf, $depot, $company);
        
        // Nom du fichier
        $filename = 'Fiche_Depot_' . $depot['numero_depot'] . '_' . date('Y-m-d') . '.pdf';
        $filename = str_replace('/', '_', $filename);
        
        // Sauvegarder dans le dossier de sortie
        $outputPath = PDF_OUTPUT_PATH . '/' . $filename;
        $pdf->Output($outputPath, 'F');
        
        // Envoyer au navigateur
        $pdf->Output($filename, 'D'); // 'D' = download, 'I' = inline
        
        Logger::info("PDF généré", ['depot_id' => $depotId, 'filename' => $filename]);
        
    } catch (Exception $e) {
        Logger::error("Erreur génération PDF", ['depot_id' => $depotId, 'error' => $e->getMessage()]);
        
        // En cas d'erreur, rediriger ou afficher une erreur
        header('Content-Type: text/html; charset=utf-8');
        echo "<h3>Erreur lors de la génération du PDF</h3>";
        echo "<p>Détails: " . htmlspecialchars($e->getMessage()) . "</p>";
        echo "<a href='javascript:history.back()'>Retour</a>";
    }
}

/**
 * Génère le contenu du PDF identique au template
 */
function generatePDFContent($pdf, $depot, $company) {
    // Couleurs
    $darkBlue = array(44, 62, 80);
    $lightGray = array(240, 240, 240);
    $black = array(0, 0, 0);
    
    // Positions Y pour l'alignement
    $y = 20;
    
    // ===== LOGO ET EN-TÊTE =====
    drawLogo($pdf, 15, $y);
    
    // Tableau principal avec les informations du dépôt
    $pdf->SetFont('helvetica', 'B', 12);
    $pdf->SetFillColor(240, 240, 240);
    $pdf->SetTextColor(0, 0, 0);
    
    // En-tête du tableau Case/No Depot/Date/Contact client
    $pdf->SetXY(60, $y);
    $pdf->Cell(30, 10, 'Case', 1, 0, 'C', true);
    $pdf->Cell(40, 10, 'No Depot', 1, 0, 'C', true);
    $pdf->Cell(30, 10, 'Date', 1, 0, 'C', true);
    $pdf->Cell(40, 10, 'Contact client', 1, 1, 'C', true);
    
    // Données du tableau
    $pdf->SetFont('helvetica', '', 11);
    $pdf->SetFillColor(255, 255, 255);
    $pdf->SetXY(60, $y + 10);
    
    // Extraire le numéro de case du numéro de dépôt (exemple: 2025/001/004 -> 4)
    $caseNumber = '';
    if (preg_match('/\/(\d+)$/', $depot['numero_depot'], $matches)) {
        $caseNumber = intval($matches[1]);
    }
    
    $pdf->Cell(30, 10, $caseNumber, 1, 0, 'C', true);
    $pdf->Cell(40, 10, $depot['numero_depot'], 1, 0, 'C', true);
    $pdf->Cell(30, 10, date('d/m/Y', strtotime($depot['date_depot'] ?: 'now')), 1, 0, 'C', true);
    $pdf->Cell(40, 10, $depot['client_nom'], 1, 1, 'C', true);
    
    $y += 35;
    
    // ===== SECTION ENTREPRISE ET DESTINATAIRE =====
    $pdf->SetXY(15, $y);
    
    // Bloc entreprise (gauche)
    $pdf->SetFont('helvetica', 'B', 10);
    $pdf->Cell(90, 6, 'Règlement, renseignement,', 0, 1, 'L');
    $pdf->SetX(15);
    $pdf->Cell(90, 6, 'correspondance :', 0, 1, 'L');
    
    $pdf->SetFont('helvetica', 'B', 11);
    $pdf->SetX(15);
    $pdf->Cell(90, 8, $company['nom'] ?? COMPANY_NAME, 0, 1, 'L');
    
    $pdf->SetFont('helvetica', '', 9);
    $adresse = $company['adresse'] ?? COMPANY_ADDRESS;
    $adresseLines = explode("\n", $adresse);
    foreach ($adresseLines as $line) {
        $pdf->SetX(15);
        $pdf->Cell(90, 5, trim($line), 0, 1, 'L');
    }
    
    $pdf->SetX(15);
    $pdf->Cell(90, 5, 'Tel. ' . ($company['tel1'] ?? COMPANY_PHONE1), 0, 1, 'L');
    $pdf->SetX(15);
    $pdf->Cell(90, 5, 'Tel. ' . ($company['tel2'] ?? COMPANY_PHONE2), 0, 1, 'L');
    $pdf->SetX(15);
    $pdf->Cell(90, 5, $company['email'] ?? COMPANY_EMAIL, 0, 1, 'L');
    
    // Bloc destinataire (droite)
    $pdf->SetXY(120, $y);
    $pdf->SetFont('helvetica', 'B', 10);
    $pdf->Cell(70, 6, 'Destinataire', 1, 1, 'C', true);
    
    $pdf->SetXY(120, $y + 6);
    $pdf->SetFont('helvetica', '', 10);
    $pdf->Cell(70, 25, $depot['client_nom'], 1, 1, 'C', false);
    
    $y += 55;
    
    // ===== SECTION DESIGNATION ET OBSERVATION =====
    $pdf->SetXY(15, $y);
    $pdf->SetFont('helvetica', 'B', 10);
    $pdf->SetFillColor(240, 240, 240);
    
    $pdf->Cell(87.5, 8, 'Désignation, Références', 1, 0, 'L', true);
    $pdf->Cell(87.5, 8, 'Observation,travaux à effectuer', 1, 1, 'L', true);
    
    // Contenu des zones de texte
    $pdf->SetFont('helvetica', '', 9);
    $pdf->SetFillColor(255, 255, 255);
    
    $designationText = $depot['designation_references'] ?: $depot['description'];
    $observationText = $depot['observation_travaux'] ?: $depot['notes'];
    
    // Zone désignation
    $pdf->SetXY(15, $y + 8);
    $pdf->MultiCell(87.5, 25, $designationText, 1, 'L', false, 0);
    
    // Zone observation
    $pdf->SetXY(102.5, $y + 8);
    $pdf->MultiCell(87.5, 25, $observationText, 1, 'L', false, 1);
    
    $y += 40;
    
    // ===== SECTION DONNEES ET MOT DE PASSE =====
    $pdf->SetXY(15, $y);
    $pdf->SetFont('helvetica', 'B', 10);
    
    $pdf->Cell(40, 8, 'Données à sauvegarder :', 0, 0, 'L');
    $pdf->SetFont('helvetica', '', 10);
    $pdf->Cell(20, 8, $depot['donnees_sauvegarder'], 0, 0, 'L');
    
    $pdf->SetFont('helvetica', 'B', 10);
    $pdf->Cell(25, 8, 'Outlook :', 0, 0, 'L');
    $pdf->SetFont('helvetica', '', 10);
    $pdf->Cell(20, 8, $depot['outlook_sauvegarder'], 0, 1, 'L');
    
    $pdf->SetXY(15, $y + 10);
    $pdf->SetFont('helvetica', 'B', 10);
    $pdf->Cell(25, 8, 'Mot de passe :', 0, 0, 'L');
    $pdf->SetFont('helvetica', '', 10);
    $pdf->Cell(100, 8, $depot['mot_de_passe'], 0, 1, 'L');
    
    $y += 25;
    
    // ===== INFORMATIONS COMPLEMENTAIRES =====
    $pdf->SetXY(15, $y);
    $pdf->SetFont('helvetica', 'B', 10);
    $pdf->SetFillColor(240, 240, 240);
    $pdf->Cell(175, 8, 'Informations complémentaires :', 1, 1, 'L', true);
    
    $pdf->SetXY(15, $y + 8);
    $pdf->SetFont('helvetica', 'B', 9);
    $pdf->SetFillColor(255, 255, 255);
    $infosComp = $depot['informations_complementaires'] ?: 'ATTENTION : LES REGLEMENTS PAR CHEQUES NE SONT PAS ACCEPTES.';
    $pdf->MultiCell(175, 10, $infosComp, 1, 'L', true);
    
    $y += 25;
    
    // ===== CONDITIONS GENERALES =====
    $pdf->SetXY(15, $y);
    $pdf->SetFont('helvetica', '', 8);
    
    $conditions = "Cette fiche de dépôt atteste que votre bien est actuellement dans nos locaux.\n";
    $conditions .= "Celle-ci vous sera demandée pour vous le restituer.\n";
    $conditions .= "Web Informatique ne saurait être tenu pour responsable de perte de données.\n";
    $conditions .= "Tout matériel déposé devient propriété de Web Informatique au-delà de " . 
                  ($company['delai_propriete'] ?? '90') . " jours à compter de la\n";
    $conditions .= "présente date sauf mention écrite.\n";
    $conditions .= "Web Informatique SARL.";
    
    $pdf->MultiCell(175, 4, $conditions, 0, 'L');
    
    $y += 35;
    
    // ===== SIGNATURES =====
    $pdf->SetXY(15, $y);
    $pdf->SetFont('helvetica', 'B', 10);
    
    // Signature client
    $pdf->Cell(87.5, 8, 'Signature client', 1, 0, 'C', true);
    // Signature entreprise
    $pdf->Cell(87.5, 8, 'Signature WEBINFORMATIQUE', 1, 1, 'C', true);
    
    // Zones de signature
    $pdf->SetXY(15, $y + 8);
    $pdf->Cell(87.5, 30, '', 1, 0, 'C');
    $pdf->Cell(87.5, 30, '', 1, 1, 'C');
    
    $y += 45;
    
    // ===== MENTIONS LEGALES =====
    $pdf->SetXY(15, $y);
    $pdf->SetFont('helvetica', '', 7);
    
    $mentions = "Web Informatique SARL au capital de " . ($company['capital'] ?? COMPANY_CAPITAL) . 
               ". SIRET: " . ($company['siret'] ?? COMPANY_SIRET) . 
               " - N° TVA intracommunautaire : " . ($company['tva'] ?? COMPANY_TVA);
    
    $pdf->Cell(175, 5, $mentions, 0, 1, 'C');
}

/**
 * Dessine le logo de l'entreprise
 */
function drawLogo($pdf, $x, $y) {
    // Logo circulaire simplifié (à remplacer par votre logo)
    $pdf->SetDrawColor(44, 62, 80);
    $pdf->SetLineWidth(2);
    $pdf->Circle($x + 15, $y + 15, 12);
    
    $pdf->SetFont('helvetica', 'B', 8);
    $pdf->SetTextColor(44, 62, 80);
    $pdf->SetXY($x + 5, $y + 10);
    $pdf->Cell(20, 5, 'WEB', 0, 1, 'C');
    $pdf->SetXY($x + 5, $y + 15);
    $pdf->Cell(20, 5, 'informatique', 0, 1, 'C');
    
    $pdf->SetTextColor(0, 0, 0);
}

/**
 * Fonction publique pour générer le PDF via URL
 */
if (isset($_GET['depot_id']) && isset($_GET['action']) && $_GET['action'] === 'pdf') {
    $depotId = intval($_GET['depot_id']);
    generateDepotPDF($depotId);
}

/**
 * Génère un PDF de test avec des données fictives
 */
function generateTestPDF() {
    $testData = [
        'id' => 999,
        'numero_depot' => '2025/188/001',
        'client_nom' => 'aze y,t',
        'prenom' => 'aze',
        'nom' => 'y,t',
        'description' => 'Test de génération PDF',
        'designation_references' => 'fghfgh',
        'observation_travaux' => 'fghfgh',
        'notes' => 'Test notes',
        'date_depot' => '2025-06-24',
        'donnees_sauvegarder' => 'Non',
        'outlook_sauvegarder' => 'Non',
        'mot_de_passe' => '',
        'informations_complementaires' => 'ATTENTION : LES REGLEMENTS PAR CHEQUES NE SONT PAS ACCEPTES.'
    ];
    
    $company = [
        'nom' => 'WEB INFORMATIQUE',
        'adresse' => "154 bis rue du général de Gaulle\n76770 LE HOULME",
        'tel1' => '06.99.50.76.76',
        'tel2' => '02.35.74.19.29',
        'email' => 'contact@webinformatique.eu',
        'siret' => '493 928 139 00010',
        'tva' => 'FR493928139',
        'capital' => '8.000€'
    ];
    
    // Créer le PDF
    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
    
    $pdf->SetCreator('Test Generator');
    $pdf->SetAuthor('WEB INFORMATIQUE');
    $pdf->SetTitle('Test Fiche de dépôt');
    
    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);
    $pdf->SetMargins(15, 15, 15);
    $pdf->SetAutoPageBreak(TRUE, 15);
    
    $pdf->AddPage();
    
    generatePDFContent($pdf, $testData, $company);
    
    $pdf->Output('Test_Fiche_Depot.pdf', 'D');
}

// Test PDF si demandé
if (isset($_GET['test']) && $_GET['test'] === 'pdf') {
    generateTestPDF();
}
?>